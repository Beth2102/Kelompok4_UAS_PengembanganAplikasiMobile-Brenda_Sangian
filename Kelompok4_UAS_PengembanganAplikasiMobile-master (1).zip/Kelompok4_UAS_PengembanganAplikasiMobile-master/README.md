# Kelompok4_UAS_PengembanganAplikasiMobile
UAS - Android Studio aplikasi News

Anggota Kelompok 4 :
- SYALOM MEGUMI FORTUNA WARONGAN_210211060198
- SAMUEL EMILIO LANELLY IRVIN KAUNANG_210211060196
- BRENDA BETTY SANGIAN_210211060126
- CRISTLIA THIA APRINE TONDONDAME_210211060221

API yang digunakan :
https://newsapi.org/

Link GDrive APK :
https://drive.google.com/drive/folders/1rFTHYVdFJYgJmEgLz7Iongefjy9LLMp6?usp=sharing

Link Video Demo Kelompok :

