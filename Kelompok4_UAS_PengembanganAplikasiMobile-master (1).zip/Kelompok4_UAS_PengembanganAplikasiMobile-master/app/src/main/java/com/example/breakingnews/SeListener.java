package com.example.breakingnews;

import com.example.breakingnews.Models.ApiNews;

public interface SeListener {
    void OnNewsClicked(ApiNews headlines);
}
